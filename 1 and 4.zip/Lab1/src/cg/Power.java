package cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Power {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		String s_n=br.readLine();
		int n=Integer.parseInt(s_n);
		
		boolean result=checkNumber(n);
		System.out.println(result);
	}

	private static boolean checkNumber(int n) {
		// TODO Auto-generated method stub
		int count=0;
		while(n!=1)
		{
			n=n/2;
			if(n%2==0)
			{
				count=1;
				if(n==2)
					break;
				continue;
			}
				
			else
			{	
				count=0;
				break;
			}
		}
		
		if(count==1)
			return true;
		else
			return false;
		
	}

}
