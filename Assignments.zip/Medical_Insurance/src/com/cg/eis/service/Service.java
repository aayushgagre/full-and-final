package com.cg.eis.service;

import com.cg.DAO.EmployeeDAO;
import com.cg.DAO.EmployeeDAOImpl;
import com.cg.eis.bean.Employee;

public class Service {
	
	EmployeeDAO dao=new EmployeeDAOImpl();
	
	public boolean addEmployeeDetails(Employee e)
	{
		return dao.addEmployeeDetails(e);
	}
	
	public Employee getEmployeeDetails(int id) {
		return dao.getEmployeeDetails(id);
	}
	
	
	
	public String generateScheme(int id, String name, double salary, String desig) {
		
		String Insurance = "";
		if((salary>5000 && salary<20000) && desig.equalsIgnoreCase("system associate"))
		{
			Insurance = "Scheme C";
		}
		if((salary>=20000 && salary<40000) && desig.equalsIgnoreCase("programmer"))
		{
			Insurance = "Scheme B";
		}
		if((salary>=40000) && desig.equalsIgnoreCase("Manager"))
		{
			Insurance = "Scheme A";
		}
		if(salary<5000 && desig.equalsIgnoreCase("clerk"))
		{
			Insurance = "No Scheme";
		}
		

		return Insurance;
	}

	public void printStatement(Employee e)
	{
		System.out.println("==========================");
		System.out.println("Employee ID: " + e.getId());

		System.out.println("Employee Name: " + e.getName());
		System.out.println("Employee Salary: " + e.getSalary());

		System.out.println("Employee Designation: " + e.getDesignation());

		System.out.println("Employee Scheme: " + e.getInsu_schm());
		System.out.println("==========================");
	}

}
