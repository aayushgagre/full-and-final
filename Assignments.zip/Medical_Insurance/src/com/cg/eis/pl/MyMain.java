package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.eis.bean.Employee;

import com.cg.eis.service.Service;
import com.cg.eis.service.Validator;

public class MyMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Service sc = new Service();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String choice = "";
		while (true) {
			System.out.println("Welcome");
			System.out.println("====================");
			System.out.println("1. Add the employee details");
			System.out.println("2. Dislay the details of employee.");

			choice = br.readLine();

			switch (choice) {
			case "1": // add the details
				int id = 0;
				String name = "";
				double salary = 0.0;
				String desig = "";
				System.out.println("Enter the employee ID");

				while (true) {
					String s_id = br.readLine();
					boolean ch1 = Validator.validatedata(s_id, Validator.aidpattern);
					if (ch1 == true) {
						try {
							id = Integer.parseInt(s_id);
							break;
						} catch (NumberFormatException e) {
							System.out.println("Employee Id must be numeric. Re Enter");
							e.printStackTrace();
						}
					} else
						System.out.println("Re enter Employee ID");
				}

				System.out.println("Enter the employee name");

				while (true) {
					String s_name = br.readLine();
					boolean ch1 = Validator.validatedata(s_name, Validator.namepattern);
					if (ch1 == true) {
						try {
							name = s_name;
							break;
						} catch (Exception e) {
							System.out.println("Employee name must be in correct format. Re enter");
							e.printStackTrace();
						}
					} else
						System.out.println("Re enter the name");
				}

				System.out.println("Enter the employee salary");

				while (true) {
					String s_salary = br.readLine();
					boolean ch1 = Validator.validatedata(s_salary, Validator.salarypattern);
					if (ch1 == true) {
						try {
							salary = Double.parseDouble(s_salary);
							break;
						} catch (NumberFormatException e) {
							System.out.println("Employee salary must be numeric. Re Enter");
							e.printStackTrace();
						}
					} else
						System.out.println("Re enter Employee salary");
				}

				System.out.println("Enter the designation of the employee");

				while (true) {
					String s_desig = br.readLine();
					boolean ch1 = Validator.validateDesignation(salary, s_desig);
					if (ch1 == true) {
						try {
							desig = s_desig;
							break;
						} catch (Exception e) {
							System.out.println("Designation is not correct");
							e.printStackTrace();
						}
					} else
						System.out.println("Designation is  not correct as per salary. Please Re enter the designatio");
				}
				//generate Scheme
				String insurance = sc.generateScheme(id, name, salary, desig);
				
				//Add employee details
				Employee e=new Employee(id,name,salary,desig,insurance);
				boolean b=sc.addEmployeeDetails(e);
				if(b)
					System.out.print("Successfully Added");
				
				break;

			case "2": // display the details
				int id1 = 0;
				System.out.println(" Enter the ID of employee ");
				while (true) {
					String s_id1 = br.readLine();
					boolean ch1 = Validator.validatedata(s_id1, Validator.aidpattern);
					if (ch1 == true) {
						try {
							id1 = Integer.parseInt(s_id1);
							break;
						} catch (NumberFormatException n) {
							System.out.println("Employee Id must be numeric. Re Enter");
							n.printStackTrace();
						}
					} else
						System.out.println("Re enter Employee ID");
				}

				Employee b1 = sc.getEmployeeDetails(id1);
				sc.printStatement(b1);

				break;
			default:
				System.out.println("Invalid choice");
			}

		}

	}

}
