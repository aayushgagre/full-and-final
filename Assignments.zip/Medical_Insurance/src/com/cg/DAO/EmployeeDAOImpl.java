package com.cg.DAO;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{
static Map<Integer, Employee> empmap=new HashMap<Integer, Employee>();
	
	@Override
	public boolean addEmployeeDetails(Employee e) {
		// TODO Auto-generated method stub
		empmap.put(e.getId(), e);
		return true;
	}

	
	@Override
	public Employee getEmployeeDetails(int id) {
		// TODO Auto-generated method stub
		Employee e=empmap.get(id);
		return e;
	}





}
