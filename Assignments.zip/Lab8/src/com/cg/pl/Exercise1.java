package com.cg.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String n="";
		System.out.println("Enter string of numbers");
		n=br.readLine();
		int sum = 0;
	    for (int i=0;i<n.length();i++) {
	      char a=n.charAt(i);
	      if (Character.isDigit(a)) {
	        int b=Integer.parseInt(String.valueOf(a));
	        System.out.print(" "+b);
	        sum=sum+b;
	      }

	}
	    System.out.println(" ");
		System.out.println("Sum :- "+sum);	
	
}
}