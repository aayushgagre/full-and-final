package com.cg.pl;

public class JournalPaper extends WrittenItem{

	public JournalPaper(int id1, String title, String author2, int noCopies,int publishedYear) {
		super(id1, title, author2, noCopies);
		this.publishedYear=publishedYear;

	}

	private int publishedYear;

	@Override
	public void checkIn(int bookId) {
	
		
	}

	@Override
	public void checkOut(int bookId) {
	
		
	}

	@Override
	public Item addItem(int id1, String title, String author, int noCopies) {

		return null;
	}

	@Override
	public void print() {

		
	}
	
	
}
