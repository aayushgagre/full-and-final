package com.cg.pl;

public class Video extends MediaItem{
	
	public Video(int bookId, String title, int noCopies, int runtime) {
		super(bookId, title, noCopies, runtime);

	}
	private String director;
	private String videogenre;
	private int yor;
	@Override
	public void checkIn(int bookId) {
	
		
	}
	@Override
	public void checkOut(int bookId) {
	
		
	}
	@Override
	public Item addItem(int id1, String title, String author, int noCopies) {
		
		return null;
	}
	@Override
	public void print() {
	
		
		
	}


}
