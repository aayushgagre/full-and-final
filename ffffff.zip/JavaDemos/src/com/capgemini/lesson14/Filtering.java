package com.capgemini.lesson14;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.capgemini.lesson13.Item;

public class Filtering {

	public static void main(String[] args) {
		
		List<String> locations = Arrays.asList(new String[]{"Pune","Mumbai","Chennai","Banglore","Noida"});
		Stream<String> stream = locations.stream();
		List<String> result = stream.filter((location)->location.length()>5).collect(Collectors.toList());
		result.stream().forEach((city)->System.out.println(city));
		System.out.println("===============");

		List<Integer> listint=Arrays.asList(11,3,44,5,66,44,33,44);
		listint.stream().filter(arg->arg>10).forEach(arg->System.out.println(arg));
		System.out.println("===============");
		
		listint.stream().distinct().forEach(arg->System.out.println(arg));
		System.out.println("===============");

		listint.stream().limit(3).forEach(arg->System.out.println(arg));
		System.out.println("===============");
		
		//count numbers
		long c=listint.stream().count();
		System.out.println("Count" + c);
		System.out.println("===============");
		System.out.println("Sum of numbers");
		int sum=listint.stream().collect(Collectors.summingInt(i->i));
		System.out.println("Sum is " + sum);
		
		Optional<Integer> opres=listint.stream().reduce((a,b)->a+b);
		int sum1=opres.get();
		System.out.println("Sum is" + sum1);
		
		System.out.println("===============");
		System.out.println("Print arrays in sorted manner");
		listint.stream().sorted().forEach(System.out::println);
		
		System.out.println("===============");
		List<Item> itlist=new ArrayList<Item>();
		itlist.add(new Item("PC", 40000.00));
		itlist.add(new Item("Laptop", 50000.00));
		itlist.add(new Item("Mobile", 33000.00));

		Comparator<Item> nameComp=(i1,i2)->i1.getName().compareTo(i2.getName());
		itlist.stream().sorted(nameComp).forEach(System.out::println);
		
		
		

		
		
	}
}
