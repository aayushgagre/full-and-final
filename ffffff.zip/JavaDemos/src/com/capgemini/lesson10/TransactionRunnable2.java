package com.capgemini.lesson10;

public class TransactionRunnable2 implements Runnable{

	int balance=1000;
	@Override
	public void run() {
		synchronized(this)
		{
			deposite(1000);
		}
	}

	public void deposite(int amount)
	{
		System.out.println("Thread start ::: " + Thread.currentThread().getName());
		System.out.println("Before deposite " + balance);
		balance=balance+amount;
		System.out.println("After deposite " + balance);
		System.out.println("Thread ended :::" + Thread.currentThread().getName());
	}
	public void printBalance()
	{
		System.out.println("Balance " + balance);
	} 
}
