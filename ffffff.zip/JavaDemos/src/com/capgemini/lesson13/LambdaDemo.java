package com.capgemini.lesson13;
@FunctionalInterface
interface SayHello
{
	public void say();
	//public void show();
}

interface PrintMsg
{
	public void print(String str);
}

interface LengthFinder
{
	public int findLength(String s);
}

interface Calculator
{
	public double add(double a, double b);
}
public class LambdaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SayHello s=()->System.out.println("Hello! Welcome to CG");
		s.say();
		
		PrintMsg p=str->System.out.println(str);
		p.print("Cap Gemini");
		
		//LengthFinder l=a->a.length();
		//LengthFinder la=(String a)->a.length();
		
		 LengthFinder l=(String a)->{
		
		  int len=a.length();
		  //System.out.println(len);
		  return len;
		  };
		  
		 
		int le=l.findLength("Capgemini");
		System.out.println(le);
		
		Calculator c=(a,b)->a+b;
		double sum=c.add(10, 5);
		System.out.println(sum);
	}

}
