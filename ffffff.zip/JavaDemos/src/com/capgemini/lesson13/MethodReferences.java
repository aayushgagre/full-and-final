package com.capgemini.lesson13;

import java.time.LocalDateTime;

interface Printable
{
	public void print(Object o);
}

class MyShow
{
	public MyShow()
	{
	}
	
	public MyShow(Object o) {
		System.out.println("MyShow Constructor " + o);
	}
	
	public void play(Object o)
	{
		System.out.println("Another Object Instance method " + o);
	}
}


public class MethodReferences {
	public static void meth1(Object o)
	{
		System.out.println("Static method" + o);
	}
	
	public void meth2(Object o)
	{
		System.out.println("Instance Method " + o);
	}

	public static void main(String[] args) {
		
		// Referring static method
		Printable p1=MethodReferences::meth1;
		p1.print(" Welcome to method references");
	
		//Reference to an instance method of a particular object
		MethodReferences ob=new MethodReferences();
		Printable p2=ob::meth2;
		p2.print(LocalDateTime.now());//print calls meth2 method of methodreferences object
		
		//Reference to an instance method of an arbitrary object of a particular type.
		MyShow ob1=new MyShow();
		Printable p3=ob1::play;
		p3.print(new Integer(40));
		
		//Reference to a constructor
		Printable p4=MyShow::new;
		p4.print(new Item("PC", 34000.00));
		
	}

}
