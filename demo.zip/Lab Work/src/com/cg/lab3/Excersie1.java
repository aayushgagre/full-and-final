package com.cg.lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Excersie1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		 int a[]=new int [5];
	        for(int i=0;i<5;i++)
	        {
	            a[i]= Integer.parseInt(br.readLine());

	        }
	        
		int num=getSecondSmallest(a);
		System.out.println(num);
	}

	private static int getSecondSmallest(int[] a) {
	
		int largest=a[0];
		int secondLargest=a[0];
		for (int i = 0; i < a.length; i++) {
			 
			if (a[i] > largest) {
				secondLargest = largest;
				largest = a[i];
 
			} else if (a[i] > secondLargest) {
				secondLargest = a[i];
 
			}
		}
		return secondLargest;
	}

	

}
