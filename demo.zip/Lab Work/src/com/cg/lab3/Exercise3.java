package com.cg.lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Exercise3 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		int a[]=new int [100];
        for(int i=0;i<5;i++)
        {
            a[i]= Integer.parseInt(br.readLine());
        }
        
        int result=getSorted(a);
        
	}

	private static int getSorted(int[] a) {
		
		int b[]=new int[100];
		for(int i=0;i<a.length;i++)
		{
			
		}
		
		
		return 0;
	}

}
