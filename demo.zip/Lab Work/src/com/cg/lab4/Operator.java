package com.cg.lab4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Operator {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		String s_n=br.readLine();
		int n=Integer.parseInt(s_n);
		int sum=0,r;
		while(n!=0)
		{
			r=n%10;
			n=n/10;
			sum=sum+r*r*r;
			
		}
		
		System.out.println(sum);
	}

}
