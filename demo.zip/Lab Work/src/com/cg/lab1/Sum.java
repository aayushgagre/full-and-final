package com.cg.lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Sum {
	
	public static void main(String s[]) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		String s_n=br.readLine();
		int n=Integer.parseInt(s_n);
		int sum=calculateSum(n);
		System.out.println("The sum of n natural numbers which are divisible by 3 or 5:" + sum);
	}

	private static int calculateSum(int n) {
		// TODO Auto-generated method stub
		
		int num=1, count=1,sum=0;
		while(count!=n+1)
		{
			if((num%3==0) || (num%5==0))
			{
				sum=sum+num;
				count++;
			}
			num++;
				
		}
		return sum;
		
	}

}
