package com.cg.lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SumOfSquares {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		String s_n=br.readLine();
		int n=Integer.parseInt(s_n);
		int dif=calculateDifference(n);
		System.out.println("the difference between the sum of the squares of the first " + n + " natural numbers and the square of their sum." + dif);
		
	}

	private static int calculateDifference(int n) {
		// TODO Auto-generated method stub
		int sumOfSquares=(n*(n+1)*((2*n)+1))/6;
		int squareOfSum=(n*n*(n+1)*(n+1))/4;
		
		int diff=sumOfSquares-squareOfSum;
		
		
		
		return diff;
	}

}
