package com.cg.lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CheckNumber {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		String s_n=br.readLine();
		int n=Integer.parseInt(s_n);
		
		boolean result=checkNumber(n);
		System.out.println(result);
		
	}

	private static boolean checkNumber(int n) {
		
		int count=0,r1,r2;
		while(n!=0)
		{
			count=0;
			r1=n%10;
			n=n/10;
			r2=n%10;
			if(r1>=r2)
			{
				count=1;
				continue;
			}
			else
			{
				count=0;
				break;
			}
		}
		if(count==1)
			return true;
		else
			return false;
		
		
	}

}
