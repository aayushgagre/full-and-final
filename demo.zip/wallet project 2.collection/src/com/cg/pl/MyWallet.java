package com.cg.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import com.cg.service.*;

import com.cg.bean.*;
import com.cg.exception.InsufficientFundException;
import com.cg.service.*;
public class MyWallet
{
	public static void main(String[] args) throws IOException, InsufficientFundException
	{
		
		
		accountservice service=new accountservice();
		
		
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		String choice="";
		while(true)
		{
			System.out.println("Welcome, you can do following");
			System.out.println("=======");
			System.out.println("1. Add a new Account");//success
			System.out.println("2. deposite money in account");//success
			System.out.println("3. Delete Account");//success
			System.out.println("4. Find account");//success
			System.out.println("5. Withdraw money");//success
			System.out.println("6. Transfer Money");
			System.out.println("7. Get all accounts");
			
			choice=br.readLine();
			switch(choice)
			{
				case"1" : 	int id=0;
							long mb=0L;
							String ah="";
							double bal=0.0;
				//Accepting and validating input for account
				System.out.println("Enter account number");
				while(true)
				{
					String s_id=br.readLine();
					boolean ch1=Validator.validatedata(s_id, Validator.aidpattern);
					if(ch1==true)
					{
						try
						{
							id=Integer.parseInt(s_id);
							break;
						}
						catch(NumberFormatException e)
						{
							System.out.println("Account number must be numeric. Re enter");
							e.printStackTrace();
						}
					}
					else
					{
						System.out.println("Re enter Account Number");
					}
				}
				System.out.println("Enter mobile number");
				while(true)
				{
					String s_mb=br.readLine();
					boolean ch1=Validator.validatedata(s_mb, Validator.mobilepattern);
					if(ch1==true)
					{
						try
						{
							mb=Long.parseLong(s_mb);
							break;
						}
						catch(NumberFormatException e)
						{
							System.out.println("Mobile number must be numeric. Re enter");
							e.printStackTrace();
						}
					}
					else
					{
						System.out.println("Re enter Account Number in 10 digits");
					}
				}
				
				System.out.println("Enter account holder name");
				//accepting and validating the account holder
				ah=br.readLine();
				
				System.out.println("Enter initial balance");

				//accepting and validating balance
				String s_bal=br.readLine();
				
				bal=Double.parseDouble(s_bal);
				
				Account ob=new Account(id,mb,ah,bal);
				boolean b=service.addAccount(ob);
				System.out.println(b);
				break;
				case"2":     //depositing money
					System.out.println("Enter the mobile number associated with the account");
					

					long mb4=0;
					while(true)
					{
						String s_mb=br.readLine();
						boolean ch1=Validator.validatedata(s_mb, Validator.mobilepattern);
						if(ch1==true)
						{
							try
							{
								mb4=Long.parseLong(s_mb);
								break;
							}
							catch(NumberFormatException e)
							{
								System.out.println("Mobile number must be numeric. Re enter");
								e.printStackTrace();
							}
						}
						else
						{
							System.out.println("Re enter Account Number in 10 digits");
						}
					}
					System.out.println("Enter the amount to be deposited in this account");
					String s_bal1=br.readLine();
					
					double bal2=Double.parseDouble(s_bal1);
					
					double b5=service.deposite(service.findAccount(mb4),bal2);
					
					System.out.println(b5);
							
						
					break;
					
				case"3": //deleting account number
						System.out.println("Enter the mobile number which account number is to be deleted");
						long mb2=0;
						while(true)
						{
							String s_mb=br.readLine();
							boolean ch1=Validator.validatedata(s_mb, Validator.mobilepattern);
							if(ch1==true)
							{
								try
								{
									mb2=Long.parseLong(s_mb);
									break;
								}
								catch(NumberFormatException e)
								{
									System.out.println("Mobile number must be numeric. Re enter");
									e.printStackTrace();
								}
							}
							else
							{
								System.out.println("Re enter Account Number in 10 digits");
							}
						}
						
						
						
						boolean b1=service.deleteAccount(service.findAccount(mb2));
						
						System.out.println(b1);
						break;
					
				case"4"://find by mobile number
					
					long mb1=0;
					System.out.println("Enter mobile number");
					while(true)
					{
						String s_mb=br.readLine();
						boolean ch1=Validator.validatedata(s_mb, Validator.mobilepattern);
						if(ch1==true)
						{
							try
							{
								mb1=Long.parseLong(s_mb);
								break;
							}
							catch(NumberFormatException e)
							{
								System.out.println("Mobile number must be numeric. Re enter");
								e.printStackTrace();
							}
						}
						else
						{
							System.out.println("Re enter Account Number in 10 digits");
						}
					}
					
					
					Account b3=service.findAccount(mb1);
					
					
					service.printStatement(b3);
		
					break;
					
					
				case "5": //withdraw money
					System.out.println("Enter the amount to be withdrawn");
					String s_bal0=br.readLine();
					double bal0=Double.parseDouble(s_bal0);
					
					System.out.println("Enter the mobile number associated with the account");
					String s_mob0=br.readLine();
					long mob0=Long.parseLong(s_mob0);
					
					service.withdraw(service.findAccount(mob0), bal0);
					
				
					
				case "6" : // transfer money 
					break;
					
				case "7": // get all accounts
					service.getAllAccounts();
					
				default : System.out.println("Invalid choice");
				
				
				
				
				
				
			}
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	/*	SavingAccount ob2=new SavingAccount(101,22222222,"raja",55000.00);
		service.printStatement(ob2);// calling default method of transaction
		double b1=0.0;
		try
		{
			b1=service.withdraw(ob2, 56000.00);
			System.out.println("after withdraw balance is"+ b1);

		}
		catch(Exception e)
		{
			System.err.println(e.getMessage());
			System.err.print(e);
		}
		double tax=service.calculatetax(gst.PCT_5, b1);
		System.out.println("GSt is : " + tax);
	*/
	}	
}
		
