package com.cg.service;


import com.cg.bean.Account;
public interface transaction
{
public double withdraw(Account ob, double amount);
public double deposit(Account ob, double amount);
public double transfermoney(Account from,Account to,double amount);
public default void printStatement(Account ob)
{
	System.out.println("==========================");
	System.out.println("statement for account no" + ob.getAid());

	System.out.println(" account Holder"+ ob.getAccountholder());
	System.out.println("balance is =>"+ ob.getBalance());
	System.out.println("==========================");
}

}
