package com.cg.service;

import com.cg.bean.*;

public class accountservice implements gst, transaction {

	@Override
	public double withdraw(Account ob, double amount) {
		double new_balance=ob.getBalance()-amount;
		if(new_balance<100.00)
		{
			ob.setBalance(new_balance);
			
		}
		return new_balance;
	}

	@Override
	public double deposit(Account ob, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double transfermoney(Account from, Account to, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculatetax(double PCT, double amount) {
		// TODO Auto-generated method stub
		return amount*gst.PCT_5;
	}

}
